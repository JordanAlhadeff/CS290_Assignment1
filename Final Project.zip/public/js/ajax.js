﻿document.addEventListener('DOMContentLoaded', getKharacters);
document.addEventListener('DOMContentLoaded', getKharactersByAlignment);
document.addEventListener('DOMContentLoaded', getSpecies);
document.addEventListener('DOMContentLoaded', getRealms);
document.addEventListener('DOMContentLoaded', getFactions);
document.addEventListener('DOMContentLoaded', getFactions_Species);
document.addEventListener('DOMContentLoaded', addKharacter);
document.addEventListener('DOMContentLoaded', deleteKharacter);
document.addEventListener('DOMContentLoaded', deleteSpecies);
document.addEventListener('DOMContentLoaded', editKharacter);
document.addEventListener('DOMContentLoaded', editSpecies);
document.addEventListener('DOMContentLoaded', editRealm);
document.addEventListener('DOMContentLoaded', editFaction);
document.addEventListener('DOMContentLoaded', updateKharacter);
document.addEventListener('DOMContentLoaded', updateSpecies);
document.addEventListener('DOMContentLoaded', updateRealm);
document.addEventListener('DOMContentLoaded', updateFaction);
document.addEventListener('DOMContentLoaded', addSpecies);
document.addEventListener('DOMContentLoaded', addRealm);
document.addEventListener('DOMContentLoaded', addFaction);
document.addEventListener('DOMContentLoaded', addSpeciesFactionRelationship);
document.getElementById('editform').style.visibility = "hidden"; 
document.getElementById('editspeciesform').style.visibility = "hidden";
document.getElementById('editrealmform').style.visibility = "hidden";
document.getElementById('editfactionform').style.visibility = "hidden";

/*
This file has all of the javascript code.  This contains the API calls to the urls from the helloMysql.js page.
If you are displaying data from the db you'll want to copy any of the get functions.  You need to add DOM content loaded
at the top of the page, you'll have the function which should be called whenever you add, update, or delete data so it will
show updated data on the page.  When you are adding data from a form, use one of the add functions.  Add a dom content loaded
event listener then write code to pull the data from the form and add to the payload.  You'll need another event listener so when the button
is pushed it calls that function.'
*/

//Prevents default form submit action
function preventDef(e) {
    e.preventDefault();

}
/*
For this function, I used code from stackoverflow.com specifically:
https://stackoverflow.com/questions/3364493/how-do-i-clear-all-options-in-a-dropdown-box
This function is used to clear my dynamically created dropdowns so I dont just keep
adding values to the drop down each time the dropdown is in focus.  i is set to the
length of the options in the drop down and for i>=0 an option will be removed and
i is decremented.
*/
function removeOptions(selectbox) {
    var i;
    for (i = selectbox.options.length - 1; i >= 0; i--) {
        selectbox.remove(i);
    }
}
/*
This function will make an API request to get all characters from
the table mk_Kharacters.  The function will dynamically create a table
and append it to the DOM
*/
function getKharacters() {
	
        var req = new XMLHttpRequest();
        req.open("GET", "http://localhost:21122/selectkharacter", true);
        req.addEventListener('load', function () {
            if (req.status >= 200 && req.status < 400) {
                var response = JSON.parse(req.responseText);
                document.getElementById('result').innerHTML = "<tr><th>First Name</th><th>Last Name</th><th>Gender</th><th>Species</th><th>Realm</th><th>Faction</th><th>Living</th><th>Alignment</th><th>Delete Kharacter</th><th>Edit Kharacter</th></tr>";
                var parsedJSON = response;
                var sex;
                var alive;
                for (var i = 0; i < parsedJSON.length; i++)
                {
                    if (parsedJSON[i].Gender == 1)
                    {
                        sex = "Female";
                    }
                    else {
                        sex = "Male";
                    }
                    if (parsedJSON[i].Living == 1) {
                        alive = "No";
                    }
                    else {
                        alive = "Yes";
                    }
                    
                    document.getElementById('result').innerHTML += "<tr><td>" +
                        parsedJSON[i].FirstName +
                        "</td><td>" +
                        parsedJSON[i].LastName +
                        "</td><td>" +
                        sex +
                        "</td><td>" +
                        parsedJSON[i].Species +
                        "</td><td>" +
                        parsedJSON[i].Realm +
                        "</td><td>" +
                        parsedJSON[i].Faction +
                        "</td><td>" +
                        alive +
                        "</td><td>" +
                        parsedJSON[i].Alignment +
                        "</td><td>" +
                        "<input type='button' id='Delete Kharacter' value='Delete Kharacter' name='" + parsedJSON[i].id + "' onclick='preventDef(event)'/>" +
                        "</td><td>" +
                         "<input type='button' id='Edit Kharacter' value='Edit Kharacter' name='" + parsedJSON[i].id + "' onclick='preventDef(event)'/>" +
                        "</td></tr>";
                    
                                     
                }
               
                
            }
            else {
                console.log("Error in network request: " + req.statusText)
            }
        });
        req.send(null);


        event.preventDefault();
    
}

/*
This function takes the value selected for alignment filter
and makes an API call and returns the kharacters that match that
alignment filter.
*/

function getKharactersByAlignment() {
    document.getElementById('Alignment Filter').addEventListener('click', function (event) {
        var req = new XMLHttpRequest();
        req.open("GET", "http://localhost:21122/selectkharactersbyalignment?Alignment=" + document.getElementById('alignmentfilter').value, true);
        req.addEventListener('load', function () {
            if (req.status >= 200 && req.status < 400) {
                var response = JSON.parse(req.responseText);
                document.getElementById('kharactersbyalignment').innerHTML = "<tr><th>First Name</th><th>Last Name</th><th>Gender</th><th>Species</th><th>Realm</th><th>Faction</th><th>Living</th><th>Alignment</th></tr>";
                var parsedJSON = response;
                var sex;
                var alive;
                for (var i = 0; i < parsedJSON.length; i++) {
                    if (parsedJSON[i].Gender == 1) {
                        sex = "Female";
                    }
                    else {
                        sex = "Male";
                    }
                    if (parsedJSON[i].Living == 1) {
                        alive = "No";
                    }
                    else {
                        alive = "Yes";
                    }

                    document.getElementById('kharactersbyalignment').innerHTML += "<tr><td>" +
                        parsedJSON[i].FirstName +
                        "</td><td>" +
                        parsedJSON[i].LastName +
                        "</td><td>" +
                        sex +
                        "</td><td>" +
                        parsedJSON[i].Species +
                        "</td><td>" +
                        parsedJSON[i].Realm +
                        "</td><td>" +
                        parsedJSON[i].Faction +
                        "</td><td>" +
                        alive +
                        "</td><td>" +
                        parsedJSON[i].Alignment +
                        "</td></tr>";


                }


            }
            else {
                console.log("Error in network request: " + req.statusText)
            }
        });
        req.send(null);


        event.preventDefault();

    });



}

/*
This function will make an API request to get all species from
the table mk_Species.  The function will dynamically create a table
and append it to the DOM
*/
function getSpecies() {

    var req = new XMLHttpRequest();
    req.open("GET", "http://localhost:21122/selectspecies", true);
    req.addEventListener('load', function () {
        if (req.status >= 200 && req.status < 400) {
            var response = JSON.parse(req.responseText);
            document.getElementById('allspecies').innerHTML = "<tr><th>Species Name</th><th>Realm of Origin</th></tr>";
            var parsedJSON = response;
            for (var i = 0; i < parsedJSON.length; i++) {
                document.getElementById('allspecies').innerHTML += "<tr><td>" +
                    parsedJSON[i].SpeciesName +
                    "</td><td>" +
                    parsedJSON[i].RealmName +
                    "</td><td>" +
                    "<input type='button' id='Delete Species' value='Delete Species' name='" + parsedJSON[i].SpeciesId + "' onclick='preventDef(event)'/>" +
                    "</td><td>" +
                    "<input type='button' id='Edit Species' value='Edit Species' name='" + parsedJSON[i].SpeciesId + "' onclick='preventDef(event)'/>" +
                    "</td></tr>";
                    
            }


        }
        else {
            console.log("Error in network request: " + req.statusText)
        }
    });
    req.send(null);


    event.preventDefault();

}

/*
This function will make an API request to get all characters from
the table mk_Realms.  The function will dynamically create a table
and append it to the DOM
*/


function getRealms() {

    var req = new XMLHttpRequest();
    req.open("GET", "http://localhost:21122/selectrealm", true);
    req.addEventListener('load', function () {
        if (req.status >= 200 && req.status < 400) {
            var response = JSON.parse(req.responseText);
            document.getElementById('allrealms').innerHTML = "<tr><th>Realm Name</th><th>Native Species</th><th>Conquered</th></tr>";
            var parsedJSON = response;
            var conqueredVar;
            for (var i = 0; i < parsedJSON.length; i++) {
                if (parsedJSON[i].Conquered == 1) {
                    conqueredVar = "No";
                }
                else {
                    conqueredVar = "Yes";
                }

                document.getElementById('allrealms').innerHTML += "<tr><td>" +
                    parsedJSON[i].RealmName +
                    "</td><td>" +
                    parsedJSON[i].SpeciesName +
                    "</td><td>" +
                    conqueredVar +
                    "</td><td>" +
                    "<input type='button' id='Edit Realm' value='Edit Realm' name='" + parsedJSON[i].RealmId + "' onclick='preventDef(event)'/>" +
                    "</td></tr>";
            }


        }
        else {
            console.log("Error in network request: " + req.statusText)
        }
    });
    req.send(null);


    event.preventDefault();

}

/*
This function will make an API request to get all characters from
the table mk_Factions.  The function will dynamically create a table
and append it to the DOM
*/

function getFactions() {

    var req = new XMLHttpRequest();
    req.open("GET", "http://localhost:21122/selectfaction", true);
    req.addEventListener('load', function () {
        if (req.status >= 200 && req.status < 400) {
            var response = JSON.parse(req.responseText);
            document.getElementById('allfactions').innerHTML = "<tr><th>Faction Name</th><th>Active</th><th>Leader</th></tr>";
            var parsedJSON = response;
            var activeVar;
            for (var i = 0; i < parsedJSON.length; i++) {
                if (parsedJSON[i].Active == 1) {
                    activeVar = "No";
                }
                else {
                    activeVar = "Yes";
                }

                document.getElementById('allfactions').innerHTML += "<tr><td>" +
                    parsedJSON[i].FactionName +
                    "</td><td>" +
                    activeVar +
                    "</td><td>" +
                    parsedJSON[i].LeaderName +
                    "</td><td>" +
                    "<input type='button' id='Edit Faction' value='Edit Faction' name='" + parsedJSON[i].FactionId + "' onclick='preventDef(event)'/>" +
                    "</td></tr>";
            }


        }
        else {
            console.log("Error in network request: " + req.statusText)
        }
    });
    req.send(null);


    event.preventDefault();

}

/*
This function will make an API request to get all characters from
the table mk_Faction_Species.  The function will dynamically create a table
and append it to the DOM
*/

function getFactions_Species() {

    var req = new XMLHttpRequest();
    req.open("GET", "http://localhost:21122/selectfaction_species", true);
    req.addEventListener('load', function () {
        if (req.status >= 200 && req.status < 400) {
            var response = JSON.parse(req.responseText);
            document.getElementById('allfactions_species').innerHTML = "<tr><th>Faction Name</th><th>Species Name</th></tr>";
            var parsedJSON = response;
            for (var i = 0; i < parsedJSON.length; i++) {

                document.getElementById('allfactions_species').innerHTML += "<tr><td>" +
                    parsedJSON[i].RelFactionName +
                    "</td><td>" +
                    parsedJSON[i].RelSpeciesName +
                    "</td></tr>";
            }


        }
        else {
            console.log("Error in network request: " + req.statusText)
        }
    });
    req.send(null);


    event.preventDefault();

}

/*
This function uses an event listener to determine when the user wants to add a character.
Data from the form is added to the payload and an API call is made to add the data to the
mk_Kharacter table.  After the call is complete the form is returned to a zero state and getKharacters is called.
*/


function addKharacter() {
    document.getElementById('Add Item').addEventListener('click', function (event) {
        if (document.getElementById('Fname').value != "")
		{
			
            var req = new XMLHttpRequest();
            var payload = { Fname: null, Lname: null, gender: null, species: null, realm: null, faction: null, living: null, alignment: null};
            payload.Fname = document.getElementById('Fname').value;
            payload.Lname = document.getElementById('Lname').value;
            payload.gender = document.getElementById('gender').value;
            payload.species = document.getElementById('species').value;
            payload.realm = document.getElementById('realm').value;
            payload.faction = document.getElementById('faction').value;
            payload.living = document.getElementById('living').value;
            payload.alignment = document.getElementById('alignment').value;
            req.open('POST', 'http://localhost:21122/insertkharacter', true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('Fname').value = "";
                    document.getElementById('Lname').value = "";
                    document.getElementById('gender').value = "";
                    document.getElementById('species').value = "";
                    document.getElementById('realm').value = "";
                    document.getElementById('faction').value = "";
                    document.getElementById('living').value = "";
                    document.getElementById('alignment').value = "";
                    getKharacters();





                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });
            req.send(JSON.stringify(payload));
            event.preventDefault();

        }
        else {
            console.log("Please enter a name");
        }

    });


}
/*
This function has an event listener that determines when a kharacter is deleted.
Once pressed the id is added to the payload and API call made to delete the character
The getKharacters and getFactions functions are called to populate the tables as data
might have changed in one or both with this delete
*/


function deleteKharacter() {
    document.addEventListener('click', function (event) {
        if (event.target && event.target.id == 'Delete Kharacter')
        {
            
            var req = new XMLHttpRequest();
            var payload = { id: null };
            payload.id = event.target.name; 
			req.open('POST', 'http://localhost:21122/deletekharacter', true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    getKharacters();
                    getFactions();
                    


                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });


            req.send(JSON.stringify(payload));
            event.preventDefault();

        }

    });


}

/*
This function has an event listener that determines when a species is deleted.
Once pressed the id is added to the payload and API call made to delete the species
The getKharacters, getSpecies, getRealms, and getFactions_Species functions are called to populate the tables as data
might have changed with this delete.
*/


function deleteSpecies() {
    document.addEventListener('click', function (event) {
        if (event.target && event.target.id == 'Delete Species') {

            var req = new XMLHttpRequest();
            var payload = { id: null };
            payload.id = event.target.name;
            req.open('POST', 'http://localhost:21122/deletespecies', true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    getSpecies();
                    getKharacters();
                    getRealms();
                    getFactions_Species();



                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });


            req.send(JSON.stringify(payload));
            event.preventDefault();

        }

    });


}

/*
This function has an event listener that determines when a kharacter is edited.
Once pressed the id is added to the payload and API call made populate the form with the kharacter's information.
*/
  
function editKharacter() {
    document.addEventListener('click', function (event) {
        if (event.target && event.target.id == 'Edit Kharacter')
        {
            
            var req = new XMLHttpRequest();
			req.open('GET', 'http://localhost:21122/editkharacter?id=' + event.target.name, true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('editform').style.visibility="visible"
                    var response = JSON.parse(req.responseText);
                    if (response[0].Gender == 1)
                    {
                        document.getElementById('editgender').selectedIndex = "1";
                    }
                    else {
                        document.getElementById('editgender').selectedIndex = "0";
                    }
                    if (response[0].Living == 1) {
                        document.getElementById('editliving').selectedIndex = "1";
                    }
                    else {
                        document.getElementById('editliving').selectedIndex = "0";
                    }
                    
                    document.getElementById('editFname').value = response[0].FirstName;
                    document.getElementById('editLname').value = response[0].LastName;
                    document.getElementById('editspecies').innerHTML = "<option value=" + response[0].SpeciesId + ">" + response[0].Species + "</option>";
                    document.getElementById('editrealm').innerHTML = "<option value=" + response[0].RealmId + ">" + response[0].Realm + "</option>";
                    document.getElementById('editfaction').innerHTML = "<option value=" + response[0].FactionId + ">" + response[0].Faction + "</option>";
                    document.getElementById('editalignment').value = response[0].Alignment;
                    document.getElementById('editKharacterId').value = response[0].id;


                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });

            
            req.send (null);
            event.preventDefault();

        }

    });

}

function editSpecies() {
    document.addEventListener('click', function (event) {
        if (event.target && event.target.id == 'Edit Species') {

            var req = new XMLHttpRequest();
            req.open('GET', 'http://localhost:21122/editspecies?id=' + event.target.name, true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('editspeciesform').style.visibility = "visible"
                    var response = JSON.parse(req.responseText);
                    document.getElementById('editspeciesName').value = response[0].SpeciesName;
                    document.getElementById('editrealmOrigin').innerHTML = "<option value=" + response[0].RealmOrigin + ">" + response[0].RealmName + "</option>";
                    document.getElementById('editSpeciesId').value = response[0].SpeciesId;


                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });


            req.send(null);
            event.preventDefault();

        }

    });

}

function editRealm() {
    document.addEventListener('click', function (event) {
        if (event.target && event.target.id == 'Edit Realm') {

            var req = new XMLHttpRequest();
            req.open('GET', 'http://localhost:21122/editrealm?id=' + event.target.name, true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('editrealmform').style.visibility = "visible"
                    var response = JSON.parse(req.responseText);
                    
                    if (response[0].Conquered == 1) {
                        document.getElementById('editconquered').selectedIndex = "1";
                    }
                    else {
                        document.getElementById('editconquered').selectedIndex = "0";
                    }
                    document.getElementById('editrealmName').value = response[0].RealmName;
                    document.getElementById('editnativeSpecies').innerHTML = "<option value=" + response[0].NativeSpecies + ">" + response[0].SpeciesName + "</option>";
                    document.getElementById('editRealmId').value = response[0].RealmId;


                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });


            req.send(null);
            event.preventDefault();

        }

    });

}

function editFaction() {
    document.addEventListener('click', function (event) {
        if (event.target && event.target.id == 'Edit Faction') {

            var req = new XMLHttpRequest();
            req.open('GET', 'http://localhost:21122/editfaction?id=' + event.target.name, true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('editfactionform').style.visibility = "visible"
                    var response = JSON.parse(req.responseText);
                    if (response[0].Active == 1) {
                        document.getElementById('editactive').selectedIndex = "1";
                    }
                    else {
                        document.getElementById('editactive').selectedIndex = "0";
                    }
                    document.getElementById('editfactionName').value = response[0].FactionName;
                    document.getElementById('editleader').innerHTML = "<option value=" + response[0].Leader + ">" + response[0].LeaderName + "</option>";
                    document.getElementById('editFactionId').value = response[0].FactionId;


                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });


            req.send(null);
            event.preventDefault();

        }

    });

}

/*
This function has an event listener that determines when an edited character is saved.
Once pressed the form data is added to the payload and an API call is made to update the
Kharacter's information.  The form is reset back to zero state.
The getKharacters function is called to show the latest kharacter data.
*/

function updateKharacter() {
    document.getElementById('Save Item').addEventListener('click', function (event) {
        
        if (document.getElementById('editFname').value != "") {
            var req = new XMLHttpRequest();
            var payload = { Fname: null, Lname: null, gender: null, species: null, realm: null, faction: null, living: null, alignment: null };
            payload.Fname = document.getElementById('editFname').value;
            payload.Lname = document.getElementById('editLname').value;
            payload.gender = document.getElementById('editgender').value;
            payload.species = document.getElementById('editspecies').value;
            payload.realm = document.getElementById('editrealm').value;
            payload.faction = document.getElementById('editfaction').value;
            payload.living = document.getElementById('editliving').value;
            payload.alignment = document.getElementById('editalignment').value;
            payload.id = document.getElementById('editKharacterId').value;
			req.open('POST', 'http://localhost:21122/updatekharacter', true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('editFname').value = "";
                    document.getElementById('editLname').value = "";
                    document.getElementById('editgender').value = "";
                    document.getElementById('editspecies').value = "";
                    document.getElementById('editrealm').value = "";
                    document.getElementById('editfaction').value = "";
                    document.getElementById('editliving').value = "";
                    document.getElementById('editalignment').value = "";
                    getKharacters();
                    document.getElementById('editform').style.visibility = "hidden"



                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });

            req.send(JSON.stringify(payload));

            event.preventDefault();

        }
        else {
            console.log("Please enter a name");

        }

    });


}

function updateSpecies() {
    document.getElementById('Save Species').addEventListener('click', function (event) {

        if (document.getElementById('editspeciesName').value != "") {
            var req = new XMLHttpRequest();
            var payload = { speciesName: null, realmOrigin: null };
            payload.speciesName = document.getElementById('editspeciesName').value;
            payload.realmOrigin = document.getElementById('editrealmOrigin').value;
            payload.id = document.getElementById('editSpeciesId').value;
            req.open('POST', 'http://localhost:21122/updatespecies', true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('editspeciesName').value = "";
                    document.getElementById('editrealmOrigin').value = "";
                    getSpecies();
                    document.getElementById('editspeciesform').style.visibility = "hidden"



                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });

            req.send(JSON.stringify(payload));

            event.preventDefault();

        }
        else {
            console.log("Please enter a name");

        }

    });


}

function updateRealm() {
    document.getElementById('Save Realm').addEventListener('click', function (event) {

        if (document.getElementById('editrealmName').value != "") {
            var req = new XMLHttpRequest();
            var payload = { realmName: null, nativeSpecies: null, conquered: null };
            payload.realmName = document.getElementById('editrealmName').value;
            payload.nativeSpecies = document.getElementById('editnativeSpecies').value;
            payload.conquered = document.getElementById('editconquered').value;
            payload.id = document.getElementById('editRealmId').value;
            req.open('POST', 'http://localhost:21122/updaterealm', true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('editrealmName').value = "";
                    document.getElementById('editnativeSpecies').value = "";
                    document.getElementById('editconquered').value = "";
                    getRealms();
                    document.getElementById('editrealmform').style.visibility = "hidden"



                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });

            req.send(JSON.stringify(payload));

            event.preventDefault();

        }
        else {
            console.log("Please enter a name");

        }

    });


}

function updateFaction() {
    document.getElementById('Save Faction').addEventListener('click', function (event) {

        if (document.getElementById('editfactionName').value != "") {
            var req = new XMLHttpRequest();
            var payload = { factionName: null, leader: null, active: null };
            payload.factionName = document.getElementById('editfactionName').value;
            payload.leader = document.getElementById('editleader').value;
            payload.active = document.getElementById('editactive').value;
            payload.id = document.getElementById('editFactionId').value;
            req.open('POST', 'http://localhost:21122/updatefaction', true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('editfactionName').value = "";
                    document.getElementById('editleader').value = "";
                    document.getElementById('editactive').value = "";
                    getFactions();
                    document.getElementById('editfactionform').style.visibility = "hidden"



                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });

            req.send(JSON.stringify(payload));

            event.preventDefault();

        }
        else {
            console.log("Please enter a name");

        }

    });


}

/*
This function uses an event listener to determine when the user wants to select a species
The function makes an API call to get species names and ids in order to populate the
dropdown
*/

document.getElementById('species').addEventListener('focus', populateSpecies('species'));
document.getElementById('nativeSpecies').addEventListener('focus', populateSpecies('nativeSpecies'));
document.getElementById('editspecies').addEventListener('focus', populateSpecies('editspecies'));
document.getElementById('relspecies').addEventListener('focus', populateSpecies('relspecies'));
document.getElementById('editnativeSpecies').addEventListener('focus', populateSpecies('editnativeSpecies'));

function populateSpecies(y) {
    document.getElementById(y).addEventListener('focus', function (event) {
        removeOptions(document.getElementById(y));
        var req = new XMLHttpRequest();
        req.open("GET", "http://localhost:21122/getspecies", true);
        req.addEventListener('load', function () {
            if (req.status >= 200 && req.status < 400) {
                var response = JSON.parse(req.responseText);
                var parsedJSON = response;
                for (var i = 0; i < parsedJSON.length; i++) {
                    document.getElementById(y).innerHTML +=
                        "<option value=" + parsedJSON[i].SpeciesId + ">" + parsedJSON[i].SpeciesName + "</option>";
                }


            }
            else {
                console.log("Error in network request: " + req.statusText)
            }
        });
        req.send(null);


        event.preventDefault();
        


    });
}

/*
This function uses an event listener to determine when the user wants to select a realm
The function makes an API call to get realm names and ids in order to populate the
dropdown
*/
editrealmOrigin

document.getElementById('realm').addEventListener('focus', populateRealm('realm'));
document.getElementById('realmOrigin').addEventListener('focus', populateRealm('realmOrigin'));
document.getElementById('editrealmOrigin').addEventListener('focus', populateRealm('editrealmOrigin'));
document.getElementById('editrealm').addEventListener('focus', populateRealm('editrealm'));

function populateRealm(x) {
    
    document.getElementById(x).addEventListener('focus', function (event) {
    
        removeOptions(document.getElementById(x));
        var req = new XMLHttpRequest();
        req.open("GET", "http://localhost:21122/getrealm", true);
        req.addEventListener('load', function () {
            if (req.status >= 200 && req.status < 400) {
                var response = JSON.parse(req.responseText);
                var parsedJSON = response;
                for (var i = 0; i < parsedJSON.length; i++) {
                    var test = document.getElementById(x).innerHTML +=
                        "<option value=" + parsedJSON[i].RealmId + ">" + parsedJSON[i].RealmName + "</option>";
                }


            }
            else {
                console.log("Error in network request: " + req.statusText)
            }
        });
        req.send(null);


        event.preventDefault();



    });
}


/*
This function uses an event listener to determine when the user wants to select a faction
The function makes an API call to get faction names and ids in order to populate the
dropdown
*/


document.getElementById('faction').addEventListener('focus', populateFaction('faction'));
document.getElementById('editfaction').addEventListener('focus', populateFaction('editfaction'));
document.getElementById('relfaction').addEventListener('focus', populateFaction('relfaction'));

function populateFaction(z) {
    document.getElementById(z).addEventListener('focus', function (event) {
        removeOptions(document.getElementById(z));
        var req = new XMLHttpRequest();
        req.open("GET", "http://localhost:21122/getfaction", true);
        req.addEventListener('load', function () {
            if (req.status >= 200 && req.status < 400) {
                var response = JSON.parse(req.responseText);
                var parsedJSON = response;
                for (var i = 0; i < parsedJSON.length; i++) {
                    document.getElementById(z).innerHTML +=
                        "<option value=" + parsedJSON[i].FactionId + ">" + parsedJSON[i].FactionName + "</option>";
                }


            }
            else {
                console.log("Error in network request: " + req.statusText)
            }
        });
        req.send(null);


        event.preventDefault();



    });
}


/*
This function uses an event listener to determine when the user wants to select a character
The function makes an API call to get character names and ids in order to populate the
dropdown
*/

document.getElementById('leader').addEventListener('focus', populateLeader('leader'));
document.getElementById('editleader').addEventListener('focus', populateLeader('editleader'));

function populateLeader(a) {
    document.getElementById(a).addEventListener('focus', function (event) {
        removeOptions(document.getElementById(a));
        var req = new XMLHttpRequest();
        req.open("GET", "http://localhost:21122/getleader", true);
        req.addEventListener('load', function () {
            if (req.status >= 200 && req.status < 400) {
                var response = JSON.parse(req.responseText);
                var parsedJSON = response;
                for (var i = 0; i < parsedJSON.length; i++) {
                    document.getElementById(a).innerHTML +=
                        "<option value=" + parsedJSON[i].id + ">" + parsedJSON[i].Leader + "</option>";
                }


            }
            else {
                console.log("Error in network request: " + req.statusText)
            }
        });
        req.send(null);


        event.preventDefault();



    });
}

/*
This function uses an event listener to determine when the user wants to select an alignment
The function makes an API call to get the alignment values in order to populate the
dropdown
*/

document.getElementById('alignmentfilter').addEventListener('focus', populateAlignment('alignmentfilter'));

function populateAlignment(a) {
    document.getElementById(a).addEventListener('focus', function (event) {
        removeOptions(document.getElementById(a));
        var req = new XMLHttpRequest();
        req.open("GET", "http://localhost:21122/getalignment", true);
        req.addEventListener('load', function () {
            if (req.status >= 200 && req.status < 400) {
                var response = JSON.parse(req.responseText);
                var parsedJSON = response;
                for (var i = 0; i < parsedJSON.length; i++) {
                    document.getElementById(a).innerHTML +=
                        "<option value=" + parsedJSON[i].Alignment + ">" + parsedJSON[i].Alignment + "</option>";
                }


            }
            else {
                console.log("Error in network request: " + req.statusText)
            }
        });
        req.send(null);


        event.preventDefault();



    });
}





/*
This function uses an event listener to determine when the user wants to add a species.
Data from the form is added to the payload and an API call is made to add the data to the
mk_Species table.  After the call is complete the form is returned to a zero state and
getSpecies is called.
*/

function addSpecies() {
    document.getElementById('Add Species').addEventListener('click', function (event) {
        if (document.getElementById('speciesName').value != "") {

            var req = new XMLHttpRequest();
            var payload = { speciesName: null, realmOrigin: null };
            payload.speciesName = document.getElementById('speciesName').value;
            payload.realmOrigin = document.getElementById('realmOrigin').value;
            req.open('POST', 'http://localhost:21122/insertspecies', true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('speciesName').value = "";
                    document.getElementById('realmOrigin').value = "";
                    getSpecies();

                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });
            req.send(JSON.stringify(payload));
            event.preventDefault();

        }
        else {
            console.log("Please enter a name");
        }

    });


}

/*
This function uses an event listener to determine when the user wants to add a realm.
Data from the form is added to the payload and an API call is made to add the data to the
mk_Realm table.  After the call is complete the form is returned to a zero state and
getRealms is called.
*/


function addRealm() {
    document.getElementById('Add Realm').addEventListener('click', function (event) {
        if (document.getElementById('realmName').value != "") {

            var req = new XMLHttpRequest();
            var payload = { realmName: null, nativeSpecies: null, conquered: null };
            payload.realmName = document.getElementById('realmName').value;
            payload.nativeSpecies = document.getElementById('nativeSpecies').value;
            payload.conquered = document.getElementById('conquered').value;
            req.open('POST', 'http://localhost:21122/insertrealm', true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('realmName').value = "";
                    document.getElementById('nativeSpecies').value = "";
                    document.getElementById('conquered').value = "";
                    getRealms();

                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });
            req.send(JSON.stringify(payload));
            event.preventDefault();

        }
        else {
            console.log("Please enter a name");
        }

    });


}

/*
This function uses an event listener to determine when the user wants to add a faction.
Data from the form is added to the payload and an API call is made to add the data to the
mk_Faction table.  After the call is complete the form is returned to a zero state and
getFactions is called.
*/

function addFaction() {
    document.getElementById('Add Faction').addEventListener('click', function (event) {
        if (document.getElementById('factionName').value != "") {

            var req = new XMLHttpRequest();
            var payload = { factionName: null, leader: null, active: null };
            payload.factionName = document.getElementById('factionName').value;
            payload.leader = document.getElementById('leader').value;
            payload.active = document.getElementById('active').value;
            req.open('POST', 'http://localhost:21122/insertfaction', true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('factionName').value = "";
                    document.getElementById('leader').value = "";
                    document.getElementById('active').value = "";
                    getFactions();

                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });
            req.send(JSON.stringify(payload));
            event.preventDefault();

        }
        else {
            console.log("Please enter a name");
        }

    });


}

/*
This function uses an event listener to determine when the user wants to add a species/faction relationship.
Data from the form is added to the payload and an API call is made to add the data to the
mk_faction_species table.  After the call is complete the form is returned to a zero state and
getFactions_Species is called.
*/

function addSpeciesFactionRelationship() {
    document.getElementById('Add Relationship').addEventListener('click', function (event) {
        if (document.getElementById('relfaction').value != "") {

            var req = new XMLHttpRequest();
            var payload = { relfaction: null, relspecies: null };
            payload.relfaction = document.getElementById('relfaction').value;
            payload.relspecies = document.getElementById('relspecies').value;
            req.open('POST', 'http://localhost:21122/insertspeciesfactionrelationship', true);
            req.setRequestHeader('Content-Type', 'application/json');
            req.addEventListener('load', function () {
                if (req.status >= 200 && req.status < 400) {
                    document.getElementById('relfaction').value = "";
                    document.getElementById('relspecies').value = "";
                    getFactions_Species();

                } else {
                    console.log("Error in network request: " + req.statusText);
                }
            });
            req.send(JSON.stringify(payload));
            event.preventDefault();

        }
        else {
            console.log("Please enter a name");
        }

    });


}













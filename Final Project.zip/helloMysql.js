var http = require("http");
var express = require('express');
var mysql = require('./dbcon.js');
var bodyParser = require('body-parser');
var session = require('express-session');//


var app = express();
var handlebars = require('express-handlebars').create({ defaultLayout: 'main' });
var request = require('request');

app.engine('handlebars', handlebars.engine);
app.set('view engine', 'handlebars');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(session({ secret: 'SuperSecretPassword' }));//
app.set('port', 21122);
app.use(express.static('public'));


//This is the node code, you should be fine copying these functions for the additions to the code
//app.get is for selecting data and app.post is for chaging data in the db.  You put your sql code in the mysql.pool.query
//You also have to add the name of the page so like app.get('/namehere').
//You want to start at the /reset-table page


app.get('/selectkharacter', function (req, res, next) {
  var context = {};
  mysql.pool.query('SELECT mk_Kharacters.id, mk_Kharacters.FirstName, mk_Kharacters.LastName, mk_Kharacters.Gender, mk_Species.SpeciesName AS Species, mk_Realm.RealmName AS Realm, mk_Faction.FactionName AS Faction, mk_Kharacters.Living, mk_Kharacters.Alignment FROM mk_Kharacters LEFT JOIN mk_Species ON mk_Kharacters.Species=mk_Species.SpeciesId LEFT JOIN mk_Realm ON mk_Kharacters.Realm=mk_Realm.RealmId LEFT JOIN mk_Faction ON mk_Kharacters.Faction=mk_Faction.FactionId', function(err, rows, fields){
    if(err){
      next(err);
      return;
    }
    context.results = rows;
    res.send(context.results);

  });
});

app.get('/selectspecies', function (req, res, next) {
    var context = {};
    mysql.pool.query('SELECT mk_Species.SpeciesId, mk_Species.SpeciesName, mk_Realm.RealmName FROM mk_Species LEFT JOIN mk_Realm ON mk_Species.RealmOrigin=mk_Realm.RealmId;', function (err, rows, fields) {
        if (err) {
            next(err);
            return;
        }
        context.results = rows;

        res.send(context.results);

    });
});

app.get('/selectrealm', function (req, res, next) {
    var context = {};
    mysql.pool.query('SELECT mk_Realm.RealmName, mk_Species.SpeciesName, mk_Realm.Conquered  FROM mk_Realm LEFT JOIN mk_Species ON mk_Realm.NativeSpecies=mk_Species.SpeciesId;', function (err, rows, fields) {
        if (err) {
            next(err);
            return;
        }
        context.results = rows;

        res.send(context.results);

    });
});

app.get('/selectfaction', function (req, res, next) {
    var context = {};
    mysql.pool.query('SELECT mk_Faction.FactionName, mk_Faction.Active, CONCAT(mk_Kharacters.FirstName, " ", mk_Kharacters.LastName) AS Leader FROM mk_Faction LEFT JOIN mk_Kharacters ON mk_Faction.Leader=mk_Kharacters.id', function (err, rows, fields) {
        if (err) {
            next(err);
            return;
        }
        context.results = rows;

        res.send(context.results);

    });
});


app.get('/getspecies', function (req, res, next) {
    var context = {};
    mysql.pool.query('SELECT SpeciesId, SpeciesName FROM mk_Species', function (err, rows, fields) {
        if (err) {
            next(err);
            return;
        }
        context.results = rows;

        res.send(context.results);

    });
});

app.get('/getrealm', function (req, res, next) {
    var context = {};
    mysql.pool.query('SELECT RealmId, RealmName FROM mk_Realm', function (err, rows, fields) {
        if (err) {
            next(err);
            return;
        }
        context.results = rows;

        res.send(context.results);

    });
});

app.get('/getfaction', function (req, res, next) {
    var context = {};
    mysql.pool.query('SELECT FactionId, FactionName FROM mk_Faction', function (err, rows, fields) {
        if (err) {
            next(err);
            return;
        }
        context.results = rows;

        res.send(context.results);

    });
});

app.get('/getleader', function (req, res, next) {
    var context = {};
    mysql.pool.query('SELECT id, CONCAT (FirstName, " ", LastName) AS Leader FROM mk_Kharacters', function (err, rows, fields) {
        if (err) {
            next(err);
            return;
        }
        context.results = rows;

        res.send(context.results);

    });
});


app.post('/insertkharacter', function (req, res, next) {
	var context = {};
	
    
        var addKharacter = {
            FirstName: req.body.Fname,
            LastName: req.body.Lname,
            Gender: req.body.gender,
            Species: req.body.species,
            Realm: req.body.realm,
            Faction: req.body.faction,
            Living: req.body.living,
            Alignment: req.body.alignment

        };
        mysql.pool.query("INSERT INTO mk_Kharacters SET ?", addKharacter, function (err, result) {
            if (err) {
                next(err);
                return;
            }
            res.send("Kharacter Added");
            
        });
});

app.post('/insertspecies', function (req, res, next) {
    var context = {};


    var addSpecies = {
        SpeciesName: req.body.speciesName,
        RealmOrigin: req.body.realmOrigin

    };
    mysql.pool.query("INSERT INTO mk_Species SET ?", addSpecies, function (err, result) {
        if (err) {
            next(err);
            return;
        }
        res.send("Kharacter Added");

    });
});

app.post('/insertrealm', function (req, res, next) {
    var context = {};


    var addRealm = {
        RealmName: req.body.realmName,
        NativeSpecies: req.body.nativeSpecies,
        Conquered: req.body.conquered

    };
    mysql.pool.query("INSERT INTO mk_Realm SET ?", addRealm, function (err, result) {
        if (err) {
            next(err);
            return;
        }
        res.send("Kharacter Added");

    });
});

app.post('/insertfaction', function (req, res, next) {
    var context = {};


    var addFaction = {
        FactionName: req.body.factionName,
        Active: req.body.active,
        Leader: req.body.leader

    };
    
    mysql.pool.query("INSERT INTO mk_Faction SET ?", addFaction, function (err, result) {
        if (err) {
            next(err);
            return;
        }
        res.send("Kharacter Added");

    });
});

app.post('/deletekharacter', function (req, res, next) {
    var context = {};




        mysql.pool.query("DELETE FROM mk_Kharacters WHERE id=?", req.body.id, function (err, result) {
            if (err) {
                console.log(err);
                next(err);
                return;
            }
            res.send("Kharacter Deleted");
            

        });
    
});

app.post('/deletespecies', function (req, res, next) {
    var context = {};




    mysql.pool.query("DELETE FROM mk_Species WHERE SpeciesId=?", req.body.id, function (err, result) {
        if (err) {
            console.log(err);
            next(err);
            return;
        }
        res.send("Species Deleted");


    });

});


app.get('/editkharacter', function (req, res, next) {
    var context = {};

    

    mysql.pool.query("SELECT mk_Kharacters.id, mk_Kharacters.FirstName, mk_Kharacters.LastName, mk_Kharacters.Gender, mk_Species.SpeciesName AS Species, mk_Species.SpeciesId, mk_Realm.RealmName AS Realm, mk_Realm.RealmId, mk_Faction.FactionName AS Faction, mk_Faction.FactionId, mk_Kharacters.Living, mk_Kharacters.Alignment FROM mk_Kharacters LEFT JOIN mk_Species ON mk_Kharacters.Species=mk_Species.SpeciesId LEFT JOIN mk_Realm ON mk_Kharacters.Realm=mk_Realm.RealmId LEFT JOIN mk_Faction ON mk_Kharacters.Faction=mk_Faction.FactionId WHERE id=?", req.query.id, function (err, result) {
            if (err) {
                next(err);
                return;
            }
            context.editresults = result;
            res.send(context.editresults);
            
        });
    



});

app.post('/updatekharacter', function (req, res, next) {
    var context = {};
    
 
        mysql.pool.query("UPDATE mk_Kharacters SET FirstName=?, LastName=?, Gender=?, Species=?, Realm=?, Faction=?, Living=?, Alignment=? WHERE id=? ", [req.body.Fname, req.body.Lname, req.body.gender, req.body.species, req.body.realm, req.body.faction, req.body.living, req.body.alignment, req.body.id], function (err, result) {
            if (err) {
                next(err);
                return;
            }
            context.results = "Inserted id " + result.insertId;
 
            res.send("Kharacter Updated");

        });
});


app.get('/reset-table', function (req, res, next) {
    res.render('home')

});

app.use(function(req,res){
  res.status(404);
  res.render('404');
});

app.use(function(err, req, res, next){
  console.error(err.stack);
  res.status(500);
  res.render('500');
});

app.listen(app.get('port'), function(){
  console.log('Express started on http://localhost:' + app.get('port') + '; press Ctrl-C to terminate.');
});

